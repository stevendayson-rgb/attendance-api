from fastapi import FastAPI, Request, HTTPException, Header
from pydantic import BaseModel
from datetime import datetime
import json

app = FastAPI()

# Replace with real tokens in production
AUTHORIZED_TOKENS = {
    "client1-token": "Client One",
    "client2-token": "Client Two"
}

# Define expected structure of the access log
class AccessLog(BaseModel):
    id: int
    time: datetime
    name: str
    user_id: str
    card: str
    method: str
    status: str
    type: str
    device: str

# POST endpoint to receive time and attendance logs
@app.post("/upload-log")
async def upload_log(log: AccessLog, authorization: str = Header(None)):
    token = authorization.replace("Bearer ", "") if authorization else None
    if token not in AUTHORIZED_TOKENS:
        raise HTTPException(status_code=401, detail="Invalid or missing token")

    client_name = AUTHORIZED_TOKENS[token]
    log_data = log.dict()
    log_data["client"] = client_name

    # Append to logs.json file (basic persistence for now)
    with open("logs.json", "a") as f:
        f.write(json.dumps(log_data, default=str) + "\n")

    print(f"[✓] Received log from {client_name}: {log_data['name']} at {log_data['time']}")
    return {"status": "success", "client": client_name}
